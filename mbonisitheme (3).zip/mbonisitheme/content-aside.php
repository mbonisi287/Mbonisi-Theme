	<h2> Aside Post: <?php the_title(); ?></h2>
	
	</div>
	<small> Posted on: <?php the_time('F j, Y'); ?> at <?php the_time('g:i a'); ?> , in <?php the_category(); ?></small>
	