//my javascript functions here in this file
