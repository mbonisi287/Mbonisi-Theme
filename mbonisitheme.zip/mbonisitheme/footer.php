		<footer>
			<p> &copy; <?php echo date('Y'); bloginfo('name'); ?></p>
		</footer>
		<?php wp_nav_menu(array('theme_location'=>'secondary')); ?>
		<?php wp_footer(); ?>		
</body>
</html>
