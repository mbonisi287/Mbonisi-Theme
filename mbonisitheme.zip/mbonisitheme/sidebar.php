<div class="sidebar" class="widgets-area">

	<?php dynamic_sidebar('sidebar-1'); ?>

</div>
