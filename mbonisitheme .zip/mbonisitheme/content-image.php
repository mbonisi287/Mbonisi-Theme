	<h2>Image Post : <?php the_title(); ?></h2>
	<div class="thumbnail-img"> <?php echo get_the_post_thumbnail($post_id, 'thumbnail'); ?>
	</div>
	